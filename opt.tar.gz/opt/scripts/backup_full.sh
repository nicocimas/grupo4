#!/bin/bash
ARCHIVO_HELP="/opt/scripts/help.txt"

# Verificar si como argumento se pasa la palabra “help”
if [[ "$1" == "-help" ]]; then
if [[ -f "$ARCHIVO_HELP" ]]; then
    cat "$ARCHIVO_HELP"
else
    echo "Archivo de ayuda no encontrado: $ARCHIVO_HELP"
fi
exit 0

# Valida si hay dos argumentos.
elif [[ $# -ne 2 ]]; then
    echo "Error: Deben proporcionarse dos argumentos: <origen> <destino>"
    echo "Pruebe: backup_full.sh -help"
    exit 1
fi

# Validar que directorios de origen y destino estén disponibles
if [[ ! -d "$1" ]]; then
    echo "Error: El directorio de origen '$1' no existe."
    exit 1
elif [[ ! -d "$2" ]]; then
    echo "Error: El directorio de destino '$2' no existe."
    exit 1
fi

# Verificar que el destino sea /backup_dir
if [ "$2" != "/backup_dir" ]; then
    echo "Error: El destino del backup debe ser /backup_dir"
    exit 1
fi

# Fecha en formato ANSI (YYYYMMDD)
FECHA=$(date +%Y%m%d)

# Nombre del archivo de backup
BACKUP=$(basename "$1")_bkp_$FECHA.tar.gz

# Crear el backup
tar -czf "$2/$BACKUP" -C "$1" .  

# Verificar si el backup se creó correctamente
if [[ -f "$2/$BACKUP" ]]; then
    echo "Backup creado correctamente: $2/$BACKUP"
else
    echo "Error: El backup no se creó correctamente"
    exit 1
fi

